# PureLiora

HTML・CSS・JavaScriptで制作したスキンケアブランドの静的サイトです。

## GitHub Pagesへの公開

1. ZIPを解凍し、このREADMEと同じ階層にあるファイルとフォルダーを、公開するGitHubリポジトリの一番上にアップロードします。index.html、css、js、images、.nojekyllなどをまとめて配置してください。
2. リポジトリの Settings → Pages を開きます。
3. Sourceを Deploy from a branch、Branchを main、フォルダーを /(root) にして Save を押します。
4. デプロイ完了後、Pages画面に表示されるURLを開きます。

通常のプロジェクト用リポジトリでは https://ユーザー名.github.io/リポジトリ名/ が公開URLになります。既存サイトを更新する場合は、そのサイトが使用しているブランチとフォルダーに配置してください。

## 内容と設定

全8ページ、ローカル画像、約8秒のオープニングと再生ボタンを含みます。ボタンは最新版の色と罫線に調整済みです。

購入URLとLINE URLは js/main.js の destinations で設定します。現在は空欄のため、購入とLINE相談は準備中表示です。

写真は生成した仮素材、価格は参考価格です。

Windowsでは index.html をダブルクリックして確認できます。URLや画像の参照は相対パスのため、プロジェクトのサブフォルダーでも表示できます。
